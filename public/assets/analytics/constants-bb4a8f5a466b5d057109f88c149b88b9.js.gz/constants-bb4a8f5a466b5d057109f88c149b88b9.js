angular.module('aku.analytics.constants', [])
.factory('factoryConstants',[function(){
  var factory = {};
  factory.d3Width = 5;
  return factory;
}]);
