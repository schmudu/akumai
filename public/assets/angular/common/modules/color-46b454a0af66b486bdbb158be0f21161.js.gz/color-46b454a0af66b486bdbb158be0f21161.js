var moduleAkuColor = angular.module('aku.common.color', []);

// ====FACTORIES
moduleAkuColor.factory('factoryColor',[function(){
  return {
    getColor: function(shapeType, id){
      return {};
    }
  };
}]);
